# Linux Basics – DevOps Practice

## Objective
This project demonstrates essential Linux command-line operations used in DevOps:

- File and directory creation/renaming
- Viewing file contents
- Searching with grep
- Zip/unzip operations
- Downloading files with wget
- File permissions with chmod
- Environment variables with export

## Project Contents

- `Linux_Basics_Documentation.docx` – Complete documentation template with commands, explanation sections, and screenshot placeholders.
- `commands.sh` – Commands used for all assignment tasks.
- `test_dir/` – Directory created during the exercise.
- `test_dir.zip` – Compressed test directory.
- `unzipped_dir/` – Extracted directory.
- `sample.txt` – File downloaded using wget.
- `secure.txt` – File with read-only permissions.

## How to Run

Run the commands in `commands.sh` in a Linux terminal:

```bash
chmod +x commands.sh
./commands.sh
```

Or execute each command manually and capture screenshots.

## GitHub Repository

Paste the final GitHub repository URL here after creating the repository.

## Submission

The complete project folder should be compressed as:

`Linux_Basics_VadePeer.zip`

Upload only this ZIP file to the submission portal, as required by the assignment.
