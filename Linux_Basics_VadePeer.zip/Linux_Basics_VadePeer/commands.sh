# Linux Basics - Commands Used
# Run these commands in order.

mkdir -p test_dir
touch test_dir/example.txt
mv test_dir/example.txt test_dir/renamed_example.txt
ls -l test_dir

cat /etc/passwd
head -n 5 /etc/passwd
tail -n 5 /etc/passwd

grep 'root' /etc/passwd

zip -r test_dir.zip test_dir/
mkdir -p unzipped_dir
unzip test_dir.zip -d unzipped_dir
find unzipped_dir -type f -ls

wget -O sample.txt https://example.com/sample.txt
ls -lh sample.txt

touch secure.txt
chmod 444 secure.txt
ls -l secure.txt

export MY_VAR='Hello, Linux!'
echo "$MY_VAR"
